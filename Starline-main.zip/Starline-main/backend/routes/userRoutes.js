const express = require('express');
const router = express.Router();
const {
  authUser,
  registerUser,
  getUserProfile,
  updateUserProfile,
} = require('../controllers/userController');
const { protect } = require('../middleware/authMiddleware');

// Wadooyinka diiwaangelinta iyo soo galida
router.post('/', registerUser);
router.post('/login', authUser);

// Waddada helitaanka profile-ka oo u baahan token (protect)
router.route('/profile')
    .get(protect, getUserProfile)
    .put(protect, updateUserProfile);

module.exports = router;
