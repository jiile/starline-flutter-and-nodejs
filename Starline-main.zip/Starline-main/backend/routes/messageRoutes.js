const express = require('express');
const router = express.Router();
const {
    createMessage,
  getMessages,
  replyToMessage,
  getMyMessages,
} = require('../controllers/messageController');
const { protect, admin } = require('../middleware/authMiddleware');

router.route('/')
    .post(createMessage)
    .get(protect, admin, getMessages);

router.route('/my').get(protect, getMyMessages);
router.route('/:id/reply').put(protect, admin, replyToMessage);

module.exports = router;
