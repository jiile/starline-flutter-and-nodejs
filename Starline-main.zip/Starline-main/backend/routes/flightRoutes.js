const express = require('express');
const router = express.Router();
const {
  getFlights,
  createFlight,
  deleteFlight,
  updateFlight,
} = require('../controllers/flightController');
const { protect, admin } = require('../middleware/authMiddleware');

// Waddada helitaanka iyo abuurista duulimaadyada
router.route('/')
    .get(getFlights)
    .post(protect, admin, createFlight); // Kaliya Admin ayaa abuuri kara

// Waddada tirtirida duulimaadka
// Waddada tirtirida duulimaadka
router.route('/:id')
    .delete(protect, admin, deleteFlight) // Kaliya Admin ayaa tirtiri kara
    .put(protect, admin, updateFlight); // Kaliya Admin ayaa badali kara

module.exports = router;
