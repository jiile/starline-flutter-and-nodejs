const jwt = require('jsonwebtoken');
const asyncHandler = require('express-async-handler');
const User = require('../models/userModel');

// Dhexdhexaadiye (Middleware) si loo hubiyo in isticmaalaha uu soo galay (Authenticated)
const protect = asyncHandler(async (req, res, next) => {
  let token;

  if (
    req.headers.authorization &&
    req.headers.authorization.startsWith('Bearer')
  ) {
    try {
      token = req.headers.authorization.split(' ')[1];

      // Furriinka token-ka si loo helo ID-ga isticmaalaha
      const decoded = jwt.verify(token, process.env.JWT_SECRET);

      req.user = await User.findById(decoded.id).select('-password');

      next();
    } catch (error) {
      console.error(error);
      res.status(401);
      throw new Error('Ma haysatid ogolaansho, token-ku wuu khaldan yahay');
    }
  }

  if (!token) {
    res.status(401);
    throw new Error('Ma haysatid ogolaansho, token ma jiro');
  }
});

// Dhexdhexaadiye si loo hubiyo in isticmaalaha uu yahay Admin
const admin = (req, res, next) => {
  if (req.user && req.user.isAdmin) {
    next();
  } else {
    res.status(401);
    throw new Error('Ma haysatid ogolaansho admin ahaan');
  }
};

module.exports = { protect, admin };
