const mongoose = require('mongoose');

// Abuurista qaabka duulimaadka (Flight Schema)
const flightSchema = mongoose.Schema(
  {
    departure: {
      type: String,
      required: true,
    },
    destination: {
      type: String,
      required: true,
    },
    price: {
      type: Number,
      required: true,
    },
    date: {
      type: Date,
      required: true,
    },
    airline: {
      type: String,
      required: true,
    },
    description: {
      type: String,
      required: false,
    },
  },
  {
    timestamps: true, // Waqtiga la abuuray iyo kan la badalay
  }
);

const Flight = mongoose.model('Flight', flightSchema);

module.exports = Flight;
