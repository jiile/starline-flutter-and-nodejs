const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

// Abuurista qaabka isticmaalaha (User Schema)
const userSchema = mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
    },
    email: {
      type: String,
      required: true,
      unique: true,
    },
    password: {
      type: String,
      required: true,
    },
    isAdmin: {
      type: Boolean,
      required: true,
      default: false,
    },
  },
  {
    timestamps: true, // Waxay ku dareysaa waqtiga la abuuray iyo kan la badalay
  }
);

// Shaqadan waxay isbarbar dhigeysaa furaha sirta ah ee la galiyay iyo kan kaydsan
userSchema.methods.matchPassword = async function (enteredPassword) {
  return await bcrypt.compare(enteredPassword, this.password);
};

// Ka hor inta aan la keydin xogta, furaha sirta ah waa in la qariyo (Hash)
userSchema.pre('save', async function (next) {
  if (!this.isModified('password')) {
    next();
  }

  const salt = await bcrypt.genSalt(10);
  this.password = await bcrypt.hash(this.password, salt);
});

const User = mongoose.model('User', userSchema);

module.exports = User;
