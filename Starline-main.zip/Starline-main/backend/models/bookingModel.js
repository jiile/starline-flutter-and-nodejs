const mongoose = require('mongoose');

const bookingSchema = mongoose.Schema(
  {
    user: {
      type: mongoose.Schema.Types.ObjectId,
      required: true,
      ref: 'User',
    },
    flight: {
      type: mongoose.Schema.Types.ObjectId,
      required: true,
      ref: 'Flight',
    },
    passengerName: {
      type: String,
      required: true,
    },
    passportNumber: {
      type: String,
      required: true,
    },
    status: {
      type: String,
      required: true,
      default: 'Pending', // Pending, Approved, Rejected
      enum: ['Pending', 'Approved', 'Rejected'],
    },
  },
  {
    timestamps: true,
  }
);

const Booking = mongoose.model('Booking', bookingSchema);

module.exports = Booking;
