const asyncHandler = require('express-async-handler');
const Booking = require('../models/bookingModel');

// @desc    Abuur dalab cusub (Create new booking)
// @route   POST /api/bookings
// @access  Private
const createBooking = asyncHandler(async (req, res) => {
  const { flightId, passengerName, passportNumber } = req.body;

  if (!flightId || !passengerName || !passportNumber) {
    res.status(400);
    throw new Error('Fadlan buuxi dhamaan meelaha banaan');
  }

  const booking = await Booking.create({
    user: req.user._id,
    flight: flightId,
    passengerName,
    passportNumber,
  });

  if (booking) {
    res.status(201).json(booking);
  } else {
    res.status(400);
    throw new Error('Lama awoodo in la abuuro dalabka');
  }
});

// @desc    Hel dalabaadkeyga (Get my bookings)
// @route   GET /api/bookings/mybookings
// @access  Private
const getMyBookings = asyncHandler(async (req, res) => {
  const bookings = await Booking.find({ user: req.user._id }).populate('flight');
  res.json(bookings);
});

// @desc    Hel dhamaan dalabaadka (Get all bookings - Admin only)
// @route   GET /api/bookings
// @access  Private/Admin
const getAllBookings = asyncHandler(async (req, res) => {
  const bookings = await Booking.find({}).populate('flight').populate('user', 'name email');
  res.json(bookings);
});

// @desc    Badal heerka dalabka (Update booking status - Admin only)
// @route   PUT /api/bookings/:id/status
// @access  Private/Admin
const updateBookingStatus = asyncHandler(async (req, res) => {
  const { status } = req.body; // 'Approved' or 'Rejected'
  
  const booking = await Booking.findById(req.params.id);

  if (booking) {
    booking.status = status;
    const updatedBooking = await booking.save();
    res.json(updatedBooking);
  } else {
    res.status(404);
    throw new Error('Dalabka lama helin');
  }
});

module.exports = {
  createBooking,
  getMyBookings,
  getAllBookings,
  updateBookingStatus,
};
