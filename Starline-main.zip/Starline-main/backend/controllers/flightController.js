const asyncHandler = require('express-async-handler');
const Flight = require('../models/flightModel');

// @desc    Helitaanka dhammaan duulimaadyada (Get all flights)
// @route   GET /api/flights
// @access  Public
const getFlights = asyncHandler(async (req, res) => {
  const flights = await Flight.find({});
  res.json(flights);
});

// @desc    Abuurista duulimaad cusub (Create a new flight)
// @route   POST /api/flights
// @access  Private/Admin
const createFlight = asyncHandler(async (req, res) => {
  const { departure, destination, price, date, airline, description } = req.body;

  const flight = new Flight({
    departure,
    destination,
    price,
    date,
    airline,
    description,
  });

  const createdFlight = await flight.save();
  res.status(201).json(createdFlight);
});

// @desc    Tirtirida duulimaad (Delete flight)
// @route   DELETE /api/flights/:id
// @access  Private/Admin
const deleteFlight = asyncHandler(async (req, res) => {
  const flight = await Flight.findById(req.params.id);

  if (flight) {
    await flight.deleteOne();
    res.json({ message: 'Duulimaadka waa la tirtiray' });
  } else {
    res.status(404);
    throw new Error('Duulimaadka lama helin');
  }
});

// @desc    Badalidda xogta duulimaadka (Update flight)
// @route   PUT /api/flights/:id
// @access  Private/Admin
const updateFlight = asyncHandler(async (req, res) => {
  const { departure, destination, price, date, airline, description } = req.body;

  const flight = await Flight.findById(req.params.id);

  if (flight) {
    flight.departure = departure || flight.departure;
    flight.destination = destination || flight.destination;
    flight.price = price || flight.price;
    flight.date = date || flight.date;
    flight.airline = airline || flight.airline;
    flight.description = description || flight.description;

    const updatedFlight = await flight.save();
    res.json(updatedFlight);
  } else {
    res.status(404);
    throw new Error('Duulimaadka lama helin');
  }
});

module.exports = {
  getFlights,
  createFlight,
  deleteFlight,
  updateFlight,
};
