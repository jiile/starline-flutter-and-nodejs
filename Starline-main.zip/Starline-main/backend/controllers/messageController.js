const asyncHandler = require('express-async-handler');
const Message = require('../models/messageModel');

// @desc    Dir Fariin (Create new message)
// @route   POST /api/messages
// @access  Public
const createMessage = asyncHandler(async (req, res) => {
  const { email, content } = req.body;

  if (!email || !content) {
    res.status(400);
    throw new Error('Fadlan gali email-ka iyo fariinta');
  }

  const message = await Message.create({
    email,
    content,
  });

  res.status(201).json(message);
});

// @desc    Hel dhammaan fariimaha (Get all messages)
// @route   GET /api/messages
// @access  Private/Admin
const getMessages = asyncHandler(async (req, res) => {
  const messages = await Message.find({}).sort({ createdAt: -1 });
  res.json(messages);
});

// @desc    Ka Jawaab Fariinta (Reply to message)
// @route   PUT /api/messages/:id/reply
// @access  Private/Admin
const replyToMessage = asyncHandler(async (req, res) => {
  const { reply } = req.body;
  const message = await Message.findById(req.params.id);

  if (message) {
    message.reply = reply;
    message.repliedAt = Date.now();
    message.read = true; 

    const updatedMessage = await message.save();
    res.json(updatedMessage);
  } else {
    res.status(404);
    throw new Error('Fariinta lama helin');
  }
});

// @desc    Hel fariimahayga (Get my messages)
// @route   GET /api/messages/my
// @access  Private
const getMyMessages = asyncHandler(async (req, res) => {
  // Assuming the user email is passed in query or body since authMiddleware might not attach user to public contact form
  // However, for a "My Messages" feature, the user SHOULD be logged in. 
  // Let's assume we use req.user.email from authMiddleware
  
  if (!req.user) {
      res.status(401);
      throw new Error('Not authorized');
  }

  const messages = await Message.find({ email: req.user.email }).sort({ createdAt: -1 });
  res.json(messages);
});

module.exports = {
  createMessage,
  getMessages,
  replyToMessage,
  getMyMessages,
};
