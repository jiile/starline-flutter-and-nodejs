const jwt = require('jsonwebtoken');

// Shaqadan waxay abuuraysaa token cusub oo isticmaalaha loo adeegsanayo
const generateToken = (id) => {
  return jwt.sign({ id }, process.env.JWT_SECRET, {
    expiresIn: '30d', // Token-ku wuxuu dhacayaa 30 maalmood kadib
  });
};

module.exports = generateToken;
