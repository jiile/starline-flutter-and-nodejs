import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import '../utils/constants.dart';
import '../models/flight.dart';

class FlightService {
  Future<String?> _getToken() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('token');
  }

  // Helitaanka dhammaan duulimaadyada (Get all flights)
  Future<List<Flight>> getFlights() async {
    final response = await http.get(Uri.parse(ApiConstants.flightsEndpoint));

    if (response.statusCode == 200) {
      List<dynamic> body = jsonDecode(response.body);
      List<Flight> flights = body.map((dynamic item) => Flight.fromJson(item)).toList();
      return flights;
    } else {
      throw Exception('Khalad ayaa ka dhacay soo qaadista xogta');
    }
  }

  // Ku darida duulimaad (Add Flight)
  Future<Flight> addFlight(Flight flight) async {
    final token = await _getToken();
    final response = await http.post(
      Uri.parse(ApiConstants.flightsEndpoint),
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $token',
      },
      body: jsonEncode({
        'departure': flight.departure,
        'destination': flight.destination,
        'price': flight.price,
        'date': flight.date.toIso8601String(),
        'airline': flight.airline,
        'description': flight.description,
      }),
    );

    if (response.statusCode == 201) {
      return Flight.fromJson(jsonDecode(response.body));
    } else {
      throw Exception('Lama awoodo in lagu daro duulimaadka');
    }
  }

  // Badalidda duulimaad (Update Flight)
  Future<Flight> updateFlight(Flight flight) async {
    final token = await _getToken();
    final response = await http.put(
      Uri.parse('${ApiConstants.flightsEndpoint}/${flight.id}'),
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $token',
      },
      body: jsonEncode({
        'departure': flight.departure,
        'destination': flight.destination,
        'price': flight.price,
        'date': flight.date.toIso8601String(),
        'airline': flight.airline,
        'description': flight.description,
      }),
    );

    if (response.statusCode == 200) {
      return Flight.fromJson(jsonDecode(response.body));
    } else {
      throw Exception('Lama awoodo in la badalo duulimaadka');
    }
  }

  // Tirtirida duulimaad (Delete Flight)
  Future<void> deleteFlight(String id) async {
    final token = await _getToken();
    final response = await http.delete(
      Uri.parse('${ApiConstants.flightsEndpoint}/$id'),
      headers: {
        'Authorization': 'Bearer $token',
      },
    );

    if (response.statusCode != 200) {
      throw Exception('Lama awoodo in la tirtiro duulimaadka');
    }
  }
}
