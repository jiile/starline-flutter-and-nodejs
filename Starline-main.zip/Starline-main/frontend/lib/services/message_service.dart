import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import '../utils/constants.dart';
import '../models/message.dart';

class MessageService {
  Future<String?> _getToken() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('token');
  }

  // Dir Fariin (Send Message)
  Future<void> sendMessage(String email, String content) async {
    final response = await http.post(
      Uri.parse(ApiConstants.messagesEndpoint),
      headers: {
        'Content-Type': 'application/json',
      },
      body: jsonEncode({
        'email': email,
        'content': content,
      }),
    );

    if (response.statusCode != 201) {
      throw Exception('Lama awoodo in la diro fariinta');
    }
  }

  // Hel Fariimaha (Get Messages - Admin only)
  Future<List<Message>> getMessages() async {
    final token = await _getToken();
    final response = await http.get(
      Uri.parse(ApiConstants.messagesEndpoint),
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $token',
      },
    );

    if (response.statusCode == 200) {
      List<dynamic> body = jsonDecode(response.body);
      List<Message> messages = body.map((dynamic item) => Message.fromJson(item)).toList();
      return messages;
    } else {
      throw Exception('Khalad ayaa ka dhacay soo qaadista fariimaha');
    }
  }

  // Jawaab Fariinta (Reply to Message - Admin only)
  Future<void> replyToMessage(String id, String reply) async {
    final token = await _getToken();
    final response = await http.put(
      Uri.parse('${ApiConstants.messagesEndpoint}/$id/reply'),
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $token',
      },
      body: jsonEncode({
        'reply': reply,
      }),
    );

    if (response.statusCode != 200) {
      print('Reply Error: ${response.statusCode}');
      print('Reply Body: ${response.body}');
      throw Exception('Lama awoodo in laga jawaabo fariinta: ${response.body}');
    }
  }

  // Hel Fariimahayga (Get My Messages - User)
  Future<List<Message>> getMyMessages() async {
    final token = await _getToken();
    final response = await http.get(
      Uri.parse('${ApiConstants.messagesEndpoint}/my'),
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $token',
      },
    );

    if (response.statusCode == 200) {
      List<dynamic> body = jsonDecode(response.body);
      List<Message> messages = body.map((dynamic item) => Message.fromJson(item)).toList();
      return messages;
    } else {
      throw Exception('Khalad ayaa ka dhacay soo qaadista fariimaha');
    }
  }
}
