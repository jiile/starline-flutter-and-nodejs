import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

class AppColors {
  // Main Colors: Blue and Gold (as per requirement)
  static const Color primary = Color(0xFF0D47A1); // Deep Blue
  static const Color secondary = Color(0xFFFFD700); // Gold
  static const Color background = Color(0xFFF5F5F5); // Light Gray/White
  static const Color text = Color(0xFF333333);
  static const Color white = Colors.white;
  static const Color error = Colors.redAccent;
}

class ApiConstants {
  static String get baseUrl {
    if (kIsWeb) {
      return 'http://127.0.0.1:5000/api';
    }
    // Android Emulator requires 10.0.2.2, Physical device requires IP, Desktop uses localhost
    if (Platform.isAndroid) {
      // 10.0.2.2 for Emulator, 192.168.18.16 for Physical Device
      // Uncomment the one you are using
      // return 'http://10.0.2.2:5000/api'; 
      return 'http://192.168.18.16:5000/api';
    }
    return 'http://192.168.18.16:5000/api'; // Host IP for other platforms if needed
  }

  static String get loginEndpoint => '$baseUrl/users/login';
  static String get registerEndpoint => '$baseUrl/users';
  static String get flightsEndpoint => '$baseUrl/flights';
  static String get messagesEndpoint => '$baseUrl/messages';
}
