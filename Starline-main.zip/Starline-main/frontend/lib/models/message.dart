class Message {
  final String? id;
  final String email;
  final String content;
  final String? reply;
  final DateTime createdAt;
  final DateTime? repliedAt;

  Message({
    this.id,
    required this.email,
    required this.content,
    this.reply,
    required this.createdAt,
    this.repliedAt,
  });

  factory Message.fromJson(Map<String, dynamic> json) {
    return Message(
      id: json['_id'],
      email: json['email'],
      content: json['content'],
      reply: json['reply'],
      createdAt: DateTime.parse(json['createdAt']),
      repliedAt: json['repliedAt'] != null ? DateTime.parse(json['repliedAt']) : null,
    );
  }
}
