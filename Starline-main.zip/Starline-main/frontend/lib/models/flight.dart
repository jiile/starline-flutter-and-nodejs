class Flight {
  final String id;
  final String departure;
  final String destination;
  final double price;
  final DateTime date;
  final String airline;
  final String? description;

  Flight({
    required this.id,
    required this.departure,
    required this.destination,
    required this.price,
    required this.date,
    required this.airline,
    this.description,
  });

  // U badalida JSON (From JSON)
  factory Flight.fromJson(Map<String, dynamic> json) {
    return Flight(
      id: json['_id'],
      departure: json['departure'],
      destination: json['destination'],
      price: json['price'].toDouble(),
      date: DateTime.parse(json['date']),
      airline: json['airline'],
      description: json['description'],
    );
  }

  // Ku badalida JSON (To JSON)
  Map<String, dynamic> toJson() {
    return {
      '_id': id,
      'departure': departure,
      'destination': destination,
      'price': price,
      'date': date.toIso8601String(),
      'airline': airline,
      'description': description,
    };
  }
}
