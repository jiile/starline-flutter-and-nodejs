import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:google_fonts/google_fonts.dart';
import '../viewmodels/auth_viewmodel.dart';
import '../viewmodels/flight_viewmodel.dart';
import '../viewmodels/message_viewmodel.dart';
import 'login_screen.dart';
import 'add_edit_flight_screen.dart';
import 'admin_messages_screen.dart';
import 'admin_messages_screen.dart';
import 'admin_bookings_screen.dart';
import 'profile_screen.dart';
import 'booking_screen.dart';
import 'user_bookings_screen.dart';
import 'user_messages_screen.dart';
import '../utils/constants.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _selectedIndex = 0; 

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      Provider.of<FlightViewModel>(context, listen: false).fetchFlights();
    });
  }

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  void _logout() {
    Provider.of<AuthViewModel>(context, listen: false).logout();
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(builder: (context) => const LoginScreen()),
    );
  }

  Widget _buildBody() {
    switch (_selectedIndex) {
      case 0:
        return _buildHomeTab();
      case 1:
        return _buildFlightsTab();
      case 2:
        return const UserBookingsScreen(showAppBar: false);
      case 3:
        return _buildAboutTab();
      case 4:
        return _buildContactTab();
      default:
        return _buildHomeTab();
    }
  }

  Widget _buildHomeTab() {
    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Hero Section
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(30),
            decoration: const BoxDecoration(
              color: AppColors.primary,
              borderRadius: BorderRadius.only(
                bottomLeft: Radius.circular(30),
                bottomRight: Radius.circular(30),
              ),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Soo Dhowow,',
                  style: GoogleFonts.poppins(color: Colors.white70, fontSize: 18),
                ),
                const SizedBox(height: 5),
                Text(
                  'Starline Travel',
                  style: GoogleFonts.poppins(
                    color: Colors.white,
                    fontSize: 28,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 10),
                Text(
                  'Sahalo safarkaaga aduunka oo dhan.',
                  style: GoogleFonts.poppins(color: Colors.white, fontSize: 14),
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Text(
              'Adeegyada Caanka ah',
              style: GoogleFonts.poppins(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: AppColors.text,
              ),
            ),
          ),
          const SizedBox(height: 10),
          // Featured Services Cards
          SizedBox(
            height: 150,
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.only(left: 20),
              children: [
                _buildServiceCard(Icons.flight, 'Duulimaadyo', Colors.blueAccent),
                _buildServiceCard(Icons.hotel, 'Hoteelo', Colors.orangeAccent),
                _buildServiceCard(Icons.local_taxi, 'Gaadiid', Colors.green),
                _buildServiceCard(Icons.verified_user, 'Visa', Colors.purpleAccent),
              ],
            ),
          ),
          const SizedBox(height: 20),
           Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Text(
              'Wararkii Ugu Dambeeyay',
              style: GoogleFonts.poppins(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: AppColors.text,
              ),
            ),
          ),
          const SizedBox(height: 10),
          Container(
            margin: const EdgeInsets.symmetric(horizontal: 20),
            padding: const EdgeInsets.all(15),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(15),
              boxShadow: [
                BoxShadow(
                  color: Colors.grey.withOpacity(0.1),
                  spreadRadius: 2,
                  blurRadius: 5,
                ),
              ],
            ),
            child: Row(
              children: [
                const Icon(Icons.notifications_active, color: AppColors.secondary, size: 40),
                const SizedBox(width: 15),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Dalab Cusub!',
                        style: GoogleFonts.poppins(fontWeight: FontWeight.bold, fontSize: 16),
                      ),
                      Text(
                        'Hadda ka hel qiimo dhimis 20% dhamaan duulimaadyada gudaha.',
                        style: GoogleFonts.poppins(fontSize: 12, color: Colors.grey[600]),
                      ),
                    ],
                  ),
                )
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildServiceCard(IconData icon, String title, Color color) {
    return GestureDetector(
      onTap: () {
        // Haddii duulimaad la taabto, tag tab-ka duulimaadyada
        if (title == 'Duulimaadyo') {
          setState(() {
            _selectedIndex = 1;
          });
        }
      },
      child: Container(
        width: 120,
        margin: const EdgeInsets.only(right: 15),
        decoration: BoxDecoration(
          color: color.withOpacity(0.1),
          borderRadius: BorderRadius.circular(15),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, size: 40, color: color),
            const SizedBox(height: 10),
            Text(
              title,
              style: GoogleFonts.poppins(
                fontWeight: FontWeight.bold,
                color: color,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFlightsTab() {
    final flightViewModel = Provider.of<FlightViewModel>(context);
    final authViewModel = Provider.of<AuthViewModel>(context, listen: false);
    final isAdmin = authViewModel.isAdmin;

    return Scaffold(
      backgroundColor: AppColors.background,
      floatingActionButton: isAdmin
          ? FloatingActionButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const AddEditFlightScreen()),
                );
              },
              backgroundColor: AppColors.secondary,
              child: const Icon(Icons.add, color: AppColors.primary),
            )
          : null,
      body: flightViewModel.isLoading
          ? const Center(child: CircularProgressIndicator())
          : flightViewModel.errorMessage != null
              ? Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text('Khalad: ${flightViewModel.errorMessage}'),
                      const SizedBox(height: 10),
                      ElevatedButton(
                        onPressed: flightViewModel.fetchFlights,
                        child: const Text('Isku day mar kale'),
                      )
                    ],
                  ),
                )
              : flightViewModel.flights.isEmpty
                  ? const Center(child: Text('Ma jiraan duulimaadyo hadda.'))
                    : ListView.builder(
                      itemCount: flightViewModel.flights.length,
                      padding: const EdgeInsets.all(16),
                      itemBuilder: (context, index) {
                        final flight = flightViewModel.flights[index];
                        return Container(
                          margin: const EdgeInsets.only(bottom: 20),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(16),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.grey.withOpacity(0.1),
                                spreadRadius: 2,
                                blurRadius: 10,
                                offset: const Offset(0, 4),
                              ),
                            ],
                          ),
                          child: Column(
                            children: [
                              // Top Section: Airline & Price
                              Container(
                                padding: const EdgeInsets.all(16),
                                decoration: const BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
                                ),
                                child: Row(
                                  children: [
                                    Container(
                                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                                      decoration: BoxDecoration(
                                        color: AppColors.primary.withOpacity(0.1),
                                        borderRadius: BorderRadius.circular(8),
                                      ),
                                      child: Row(
                                        children: [
                                          const Icon(Icons.airlines, color: AppColors.primary, size: 20),
                                          const SizedBox(width: 5),
                                          Text(
                                            flight.airline,
                                            style: const TextStyle(fontWeight: FontWeight.bold, color: AppColors.primary),
                                          ),
                                        ],
                                      ),
                                    ),
                                    const Spacer(),
                                    Text(
                                      '\$${flight.price}',
                                      style: GoogleFonts.poppins(
                                        fontWeight: FontWeight.bold,
                                        fontSize: 22,
                                        color: const Color(0xFF00C853), // Rich Green
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              // Middle Section: Route
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text(flight.departure, style: GoogleFonts.poppins(fontSize: 18, fontWeight: FontWeight.bold)),
                                        const Text('Macsalaamo', style: TextStyle(color: Colors.grey, fontSize: 12)),
                                      ],
                                    ),
                                    Expanded(
                                      child: Padding(
                                        padding: const EdgeInsets.symmetric(horizontal: 10),
                                        child: Column(
                                          children: [
                                            const Icon(Icons.flight_takeoff, color: Colors.grey),
                                            const Divider(color: Colors.grey),
                                            Text(
                                              flight.date.toString().substring(0, 10),
                                              style: const TextStyle(color: Colors.grey, fontSize: 10),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                    Column(
                                      crossAxisAlignment: CrossAxisAlignment.end,
                                      children: [
                                        Text(flight.destination, style: GoogleFonts.poppins(fontSize: 18, fontWeight: FontWeight.bold)),
                                        const Text('Soo Dhaweyn', style: TextStyle(color: Colors.grey, fontSize: 12)),
                                      ],
                                    ),
                                  ],
                                ),
                              ),
                              // Dotted Line Divider
                              Padding(
                                padding: const EdgeInsets.symmetric(horizontal: 10),
                                child: Row(
                                  children: List.generate(30, (index) => Expanded(
                                    child: Container(
                                      color: index % 2 == 0 ? Colors.transparent : Colors.grey.shade300,
                                      height: 1,
                                    ),
                                  )),
                                ),
                              ),
                              // Bottom Section: Actions
                              Padding(
                                padding: const EdgeInsets.all(16),
                                child: Row(
                                  children: [
                                    const Icon(Icons.info_outline, size: 16, color: Colors.black54),
                                    const SizedBox(width: 5),
                                    Expanded(
                                      child: Text(
                                        flight.description ?? 'Rakaab raaxo leh',
                                        style: GoogleFonts.poppins(
                                          color: Colors.black87,
                                          fontSize: 13,
                                          fontWeight: FontWeight.w600, // Bold wax yar
                                        ),
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                    ),
                                    if (isAdmin) 
                                      Row(
                                        children: [
                                          IconButton(
                                            icon: const Icon(Icons.edit, color: Colors.blue),
                                            onPressed: () {
                                              Navigator.push(
                                                context,
                                                MaterialPageRoute(builder: (context) => AddEditFlightScreen(flight: flight)),
                                              );
                                            },
                                          ),
                                          IconButton(
                                            icon: const Icon(Icons.delete, color: Colors.red),
                                            onPressed: () => _showDeleteConfirmation(context, flight.id),
                                          ),
                                        ],
                                      )
                                    else
                                      ElevatedButton(
                                        onPressed: () {
                                          Navigator.push(
                                            context,
                                            MaterialPageRoute(builder: (context) => BookingScreen(flight: flight)),
                                          );
                                        },
                                        style: ElevatedButton.styleFrom(
                                          backgroundColor: AppColors.primary,
                                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                                          padding: const EdgeInsets.symmetric(horizontal: 20),
                                        ),
                                        child: const Text('Book Now', style: TextStyle(color: Colors.white)),
                                      ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        );
                      },
                    ),
    );
  }

  void _showDeleteConfirmation(BuildContext context, String flightId) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Hubin Tirtiris'),
        content: const Text('Ma hubtaa inaad tirtirto duulimaadkan?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(),
            child: const Text('Maya'),
          ),
          TextButton(
            onPressed: () {
              Navigator.of(ctx).pop();
              Provider.of<FlightViewModel>(context, listen: false).deleteFlight(flightId);
            },
            child: const Text('Haa, Tirtir', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }

  Widget _buildAboutTab() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Center(
            child: Container(
              height: 120,
              width: 120,
              decoration: BoxDecoration(
                color: AppColors.primary.withOpacity(0.1),
                shape: BoxShape.circle,
              ),
              child: const Icon(
                Icons.travel_explore,
                size: 60,
                color: AppColors.primary,
              ),
            ),
          ),
          const SizedBox(height: 20),
          Center(
            child: Text(
              'Starline Travel',
              style: GoogleFonts.poppins(
                fontSize: 26,
                fontWeight: FontWeight.bold,
                color: AppColors.primary,
              ),
            ),
          ),
          const SizedBox(height: 10),
          Center(
            child: Text(
              'Sahalkaaga Safarka',
              style: GoogleFonts.poppins(
                fontSize: 16,
                color: Colors.grey[600],
                fontStyle: FontStyle.italic,
              ),
            ),
          ),
          const SizedBox(height: 30),
          _buildInfoCard(
            'Ku saabsan',
            'Starline Travel waa shirkad casri ah oo bixisa adeegyada safarka iyo dalxiiska. Waxaan u taaganahay inaan macaamiisheena siino khibrad safar oo aan la ilaawi karin.',
            Icons.info_outline,
            Colors.blue,
          ),
          const SizedBox(height: 15),
          _buildInfoCard(
            'Hadafkeena',
            'Inaan noqono shirkada ugu horeysa ee bixisa adeegyada safarka ee ugu tayada wanaagsan Geeska Afrika, annagoo adeegsanayna tiknoolajiyad casri ah.',
            Icons.flag,
            Colors.orange,
          ),
          const SizedBox(height: 15),
          _buildInfoCard(
            'Maxaad noo doorataa?',
            '• Adeeg hufan oo 24/7 ah\n• Qiimo jaban oo ku raali galiya\n• Duulimaadyo caalami ah iyo kuwo gudaha ah',
            Icons.check_circle,
            Colors.green,
          ),
          const SizedBox(height: 30),
          Center(
            child: Text(
              'Version 1.0.0',
              style: TextStyle(color: Colors.grey[400]),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInfoCard(String title, String content, IconData icon, Color color) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(15),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.1),
            spreadRadius: 2,
            blurRadius: 5,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, color: color, size: 24),
              const SizedBox(width: 10),
              Text(
                title,
                style: GoogleFonts.poppins(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: AppColors.text,
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Text(
            content,
            style: GoogleFonts.poppins(
              fontSize: 14,
              color: Colors.grey[700],
              height: 1.5,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildContactTab() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Center(
            child: Container(
              height: 120,
              width: 120,
              decoration: BoxDecoration(
                color: AppColors.secondary.withOpacity(0.1),
                shape: BoxShape.circle,
              ),
              child: const Icon(
                Icons.support_agent,
                size: 60,
                color: AppColors.secondary,
              ),
            ),
          ),
          const SizedBox(height: 20),
          Center(
            child: Text(
              'Nala soo xiriir',
              style: GoogleFonts.poppins(
                fontSize: 26,
                fontWeight: FontWeight.bold,
                color: AppColors.primary,
              ),
            ),
          ),
          const SizedBox(height: 10),
          Center(
            child: Text(
              'Waxaan diyaar u nahay inaan ku caawino',
              style: GoogleFonts.poppins(
                fontSize: 16,
                color: Colors.grey[600],
              ),
              textAlign: TextAlign.center,
            ),
          ),
          const SizedBox(height: 30),
          _buildContactCard(
              Icons.location_on, 'Goobta', 'Maka Al-Mukarama, Mogadishu'),
          const SizedBox(height: 15),
          _buildContactCard(Icons.phone, 'Telefoonka', '+252 61 5000000'),
          const SizedBox(height: 15),
          _buildContactCard(Icons.email, 'Email-ka', 'info@starline.so'),
          const SizedBox(height: 15),
          _buildContactCard(
              Icons.access_time, 'Saacadaha Shaqada', 'Sabti - Khamiis: 8:00 AM - 8:00 PM'),
          const SizedBox(height: 30),
          SizedBox(
            width: double.infinity,
            child: OutlinedButton.icon(
              onPressed: () {
                Navigator.of(context).push(
                  MaterialPageRoute(builder: (context) => const UserMessagesScreen()),
                );
              },
              icon: const Icon(Icons.inbox, color: AppColors.primary),
              label: const Text('Fariimahayga (Inbox)', style: TextStyle(color: AppColors.primary)),
              style: OutlinedButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 15),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
                side: const BorderSide(color: AppColors.primary),
              ),
            ),
          ),
          const SizedBox(height: 15),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: () {
                _showSendMessageDialog(context);
              },
              icon: const Icon(Icons.message, color: Colors.white),
              label: const Text('Dir Fariin (Send Message)', style: TextStyle(color: Colors.white)),
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.primary,
                padding: const EdgeInsets.symmetric(vertical: 15),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _showSendMessageDialog(BuildContext context) {
    final emailController = TextEditingController();
    final messageController = TextEditingController();
    final _formKey = GlobalKey<FormState>();

    showDialog(
      context: context,
      builder: (ctx) => Dialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        elevation: 10,
        backgroundColor: Colors.white,
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // Header
              Container(
                width: double.infinity,
                padding: const EdgeInsets.symmetric(vertical: 20),
                decoration: const BoxDecoration(
                  color: AppColors.primary,
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(20),
                    topRight: Radius.circular(20),
                  ),
                ),
                child: Column(
                  children: [
                    const Icon(Icons.mark_email_unread, color: Colors.white, size: 50),
                    const SizedBox(height: 10),
                    Text(
                      'Dir Fariin',
                      style: GoogleFonts.poppins(
                        color: Colors.white,
                        fontSize: 22,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(20),
                child: Form(
                  key: _formKey,
                  child: Column(
                    children: [
                      Text(
                        'Nagu soo biir fariintaada, waan ka jawaabi doonaa sida ugu dhaqsaha badan.',
                        textAlign: TextAlign.center,
                        style: GoogleFonts.poppins(
                          color: Colors.grey[600],
                          fontSize: 14,
                        ),
                      ),
                      const SizedBox(height: 20),
                      TextFormField(
                        controller: emailController,
                        decoration: InputDecoration(
                          labelText: 'Email-kaaga',
                          prefixIcon: const Icon(Icons.email_outlined, color: AppColors.primary),
                          filled: true,
                          fillColor: Colors.grey[50],
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(15),
                            borderSide: BorderSide.none,
                          ),
                          enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(15),
                            borderSide: BorderSide(color: Colors.grey.shade200),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(15),
                            borderSide: const BorderSide(color: AppColors.primary),
                          ),
                        ),
                        validator: (value) => value!.isEmpty ? 'Fadlan gali email' : null,
                      ),
                      const SizedBox(height: 15),
                      TextFormField(
                        controller: messageController,
                        decoration: InputDecoration(
                          labelText: 'Fariintaada',
                          prefixIcon: const Icon(Icons.message_outlined, color: AppColors.primary),
                          filled: true,
                          fillColor: Colors.grey[50],
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(15),
                            borderSide: BorderSide.none,
                          ),
                          enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(15),
                            borderSide: BorderSide(color: Colors.grey.shade200),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(15),
                            borderSide: const BorderSide(color: AppColors.primary),
                          ),
                        ),
                        maxLines: 4,
                        validator: (value) => value!.isEmpty ? 'Fadlan gali fariin' : null,
                      ),
                      const SizedBox(height: 25),
                      Row(
                        children: [
                          Expanded(
                            child: OutlinedButton(
                              onPressed: () => Navigator.of(ctx).pop(),
                              style: OutlinedButton.styleFrom(
                                padding: const EdgeInsets.symmetric(vertical: 15),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(10),
                                ),
                                side: BorderSide(color: Colors.grey.shade300),
                              ),
                              child: Text(
                                'Jooji',
                                style: GoogleFonts.poppins(color: Colors.grey[700]),
                              ),
                            ),
                          ),
                          const SizedBox(width: 15),
                          Expanded(
                            child: ElevatedButton(
                              onPressed: () async {
                                if (_formKey.currentState!.validate()) {
                                  // Show loading indicator inside button logic if possible, 
                                  // but for now we block double taps or assume fast internet.
                                  // Better UX: Show dialog loading
                                  
                                  final success = await Provider.of<MessageViewModel>(context, listen: false)
                                      .sendMessage(emailController.text, messageController.text);
                                  
                                  Navigator.of(ctx).pop();
                                  
                                  if (success) {
                                    ScaffoldMessenger.of(context).showSnackBar(
                                      const SnackBar(
                                        content: Text('Fariintaada waa la diray!'),
                                        backgroundColor: Colors.green,
                                      ),
                                    );
                                  } else {
                                    ScaffoldMessenger.of(context).showSnackBar(
                                      const SnackBar(
                                        content: Text('Khalad ayaa dhacay, fadlan isku day mar kale.'),
                                        backgroundColor: Colors.red,
                                      ),
                                    );
                                  }
                                }
                              },
                              style: ElevatedButton.styleFrom(
                                backgroundColor: AppColors.primary,
                                padding: const EdgeInsets.symmetric(vertical: 15),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(10),
                                ),
                                elevation: 0,
                              ),
                              child: Text(
                                'Dir Fariin',
                                style: GoogleFonts.poppins(
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          ),
                        ],
                      )
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildContactCard(IconData icon, String title, String content) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 15),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(15),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.05),
            spreadRadius: 2,
            blurRadius: 5,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: AppColors.primary.withOpacity(0.1),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(icon, color: AppColors.primary, size: 24),
          ),
          const SizedBox(width: 15),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: GoogleFonts.poppins(
                    fontWeight: FontWeight.bold,
                    fontSize: 14,
                    color: Colors.grey[600],
                  ),
                ),
                Text(
                  content,
                  style: GoogleFonts.poppins(
                    fontWeight: FontWeight.w600,
                    fontSize: 16,
                    color: AppColors.text,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    String title = 'Home';
    if (_selectedIndex == 1) title = 'Flights / Services';
    if (_selectedIndex == 2) title = 'My Bookings';
    if (_selectedIndex == 3) title = 'About Us';
    if (_selectedIndex == 4) title = 'Contact Us';

    return Scaffold(
      appBar: AppBar(
        title: Text(title, style: GoogleFonts.poppins(color: Colors.white)),
        backgroundColor: AppColors.primary,
        iconTheme: const IconThemeData(color: Colors.white),
        actions: [
          IconButton(
            icon: const Icon(Icons.account_circle),
            tooltip: 'Profile',
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const ProfileScreen()),
              );
            },
          ),
          // Show Inbox icon only for Admin
          if (Provider.of<AuthViewModel>(context).isAdmin) ...[
            IconButton(
              icon: const Icon(Icons.inbox),
              tooltip: 'Fariimaha (Messages)',
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const AdminMessagesScreen()),
                );
              },
            ),
            IconButton(
              icon: const Icon(Icons.assignment_turned_in),
              tooltip: 'Dalabaadka (Bookings)',
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const AdminBookingsScreen()),
                );
              },
            ),
          ],
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: _logout,
            tooltip: 'Ka bax (Logout)',
          ),
        ],
      ),
      body: _buildBody(),
      bottomNavigationBar: Container(
        decoration: BoxDecoration(
          boxShadow: [
            BoxShadow(
              color: Colors.grey.withOpacity(0.2),
              spreadRadius: 2,
              blurRadius: 10,
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: const BorderRadius.only(
            topLeft: Radius.circular(20),
            topRight: Radius.circular(20),
          ),
          child: BottomNavigationBar(
            items: const <BottomNavigationBarItem>[
              BottomNavigationBarItem(
                icon: Icon(Icons.home),
                label: 'Home',
              ),
              BottomNavigationBarItem(
                icon: Icon(Icons.airplane_ticket),
                label: 'Flights',
              ),
              BottomNavigationBarItem(
                icon: Icon(Icons.history),
                label: 'Bookings',
              ),
              BottomNavigationBarItem(
                icon: Icon(Icons.info),
                label: 'About',
              ),
              BottomNavigationBarItem(
                icon: Icon(Icons.contact_support),
                label: 'Contact',
              ),
            ],
            currentIndex: _selectedIndex,
            selectedItemColor: AppColors.primary,
            unselectedItemColor: Colors.grey,
            showUnselectedLabels: true,
            type: BottomNavigationBarType.fixed,
            onTap: _onItemTapped,
            backgroundColor: Colors.white,
            elevation: 0,
          ),
        ),
      ),
    );
  }
}
