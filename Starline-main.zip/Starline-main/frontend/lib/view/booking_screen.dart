import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import '../models/flight.dart';
import '../viewmodels/booking_viewmodel.dart';
import '../utils/constants.dart';
import 'payment_screen.dart';

class BookingScreen extends StatefulWidget {
  final Flight flight;

  const BookingScreen({super.key, required this.flight});

  @override
  State<BookingScreen> createState() => _BookingScreenState();
}

class _BookingScreenState extends State<BookingScreen> {
  final _passengerNameController = TextEditingController();
  final _passportController = TextEditingController();
  final _formKey = GlobalKey<FormState>();

  @override
  void dispose() {
    _passengerNameController.dispose();
    _passportController.dispose();
    super.dispose();
  }

  void _submitBooking() {
    if (_formKey.currentState!.validate()) {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => PaymentScreen(
            flight: widget.flight,
            passengerName: _passengerNameController.text.trim(),
            passportNumber: _passportController.text.trim(),
          ),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Dalbo Duulimaad', style: GoogleFonts.poppins(color: Colors.white)),
        backgroundColor: AppColors.primary,
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Flight Summary Card
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: Colors.blue.shade50,
                borderRadius: BorderRadius.circular(15),
                border: Border.all(color: Colors.blue.shade100),
              ),
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(widget.flight.airline, style: GoogleFonts.poppins(fontWeight: FontWeight.bold, fontSize: 18)),
                      Text('\$${widget.flight.price}', style: GoogleFonts.poppins(fontWeight: FontWeight.bold, fontSize: 18, color: const Color(0xFF00C853))),
                    ],
                  ),
                  const Divider(),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text('Ka imaanaya', style: TextStyle(color: Colors.grey, fontSize: 12)),
                          Text(widget.flight.departure, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                        ],
                      ),
                      const Icon(Icons.flight_takeoff, color: AppColors.primary),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          const Text('Ku socda', style: TextStyle(color: Colors.grey, fontSize: 12)),
                          Text(widget.flight.destination, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                        ],
                      ),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 30),
            
            Text(
              'Xogta Rakaabka',
              style: GoogleFonts.poppins(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 15),
            
            Form(
              key: _formKey,
              child: Column(
                children: [
                  TextFormField(
                    controller: _passengerNameController,
                    decoration: const InputDecoration(
                      labelText: 'Magaca Rakaabka (Full Name)',
                      border: OutlineInputBorder(),
                      prefixIcon: Icon(Icons.person),
                    ),
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Fadlan gali magaca';
                      }
                      
                      // Check for at least two words
                      List<String> names = value.trim().split(' ');
                      if (names.length < 2) {
                        return 'Fadlan gali magaca oo saddexan (Full Name required)';
                      }
                      
                      // Check for fake/garbage names (simple check: length > 3)
                      if (value.length < 4) {
                         return 'Magaca waa inuu sax ahaadaa';
                      }

                      return null;
                    },
                  ),
                  const SizedBox(height: 20),
                  TextFormField(
                    controller: _passportController,
                    decoration: const InputDecoration(
                      labelText: 'Passport Number',
                      border: OutlineInputBorder(),
                      prefixIcon: Icon(Icons.credit_card),
                    ),
                    validator: (value) => value!.isEmpty ? 'Fadlan gali Passport Number' : null,
                  ),
                  const SizedBox(height: 30),
                  SizedBox(
                    width: double.infinity,
                    child: Consumer<BookingViewModel>(
                      builder: (context, viewModel, child) {
                        return ElevatedButton(
                          onPressed: viewModel.isLoading ? null : _submitBooking,
                          style: ElevatedButton.styleFrom(
                            backgroundColor: AppColors.primary,
                            padding: const EdgeInsets.symmetric(vertical: 15),
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                          ),
                          child: viewModel.isLoading 
                              ? const CircularProgressIndicator(color: Colors.white)
                              : const Text('Gudub Lacag Bixinta (Proceed to Payment)', style: TextStyle(color: Colors.white, fontSize: 16)),
                        );
                      }
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
