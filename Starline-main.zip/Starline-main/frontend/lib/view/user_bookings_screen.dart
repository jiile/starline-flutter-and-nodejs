import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:google_fonts/google_fonts.dart';
import '../viewmodels/booking_viewmodel.dart';
import 'ticket_screen.dart';
import '../utils/constants.dart';

class UserBookingsScreen extends StatefulWidget {
  final bool showAppBar;
  const UserBookingsScreen({super.key, this.showAppBar = true});

  @override
  State<UserBookingsScreen> createState() => _UserBookingsScreenState();
}

class _UserBookingsScreenState extends State<UserBookingsScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      // Fetch user's own bookings
      Provider.of<BookingViewModel>(context, listen: false).fetchBookings(isAdmin: false);
    });
  }

  @override
  Widget build(BuildContext context) {
    // If showAppBar is false, return only the body content directly
    // If true, return Scaffold with AppBar
    Widget bodyContent = Consumer<BookingViewModel>(
      builder: (context, viewModel, child) {
        if (viewModel.isLoading) {
          return const Center(child: CircularProgressIndicator());
        }

        if (viewModel.errorMessage != null) {
          return Center(child: Text('Khalad: ${viewModel.errorMessage}'));
        }

        if (viewModel.bookings.isEmpty) {
          return Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(Icons.airplane_ticket_outlined, size: 80, color: Colors.grey),
                const SizedBox(height: 20),
                Text(
                  'Wali wax dalab ah ma sameyn.',
                  style: GoogleFonts.poppins(fontSize: 16, color: Colors.grey),
                ),
              ],
            ),
          );
        }

        return ListView.builder(
          padding: const EdgeInsets.all(16),
          itemCount: viewModel.bookings.length,
          itemBuilder: (context, index) {
            final booking = viewModel.bookings[index];
            final flight = booking['flight'];

            return Card(
              margin: const EdgeInsets.only(bottom: 16),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
              elevation: 4,
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Header: Status and Date
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                          decoration: BoxDecoration(
                            color: _getStatusColor(booking['status']).withOpacity(0.1),
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: Row(
                            children: [
                              Icon(_getStatusIcon(booking['status']), size: 16, color: _getStatusColor(booking['status'])),
                              const SizedBox(width: 5),
                              Text(
                                booking['status'],
                                style: TextStyle(
                                  color: _getStatusColor(booking['status']),
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ],
                          ),
                        ),
                        Text(
                          flight != null ? flight['date'].toString().substring(0, 10) : '',
                          style: const TextStyle(color: Colors.grey, fontSize: 12),
                        ),
                      ],
                    ),
                    const Divider(),

                    // Flight Details
                    if (flight != null) ...[
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(flight['departure'], style: GoogleFonts.poppins(fontWeight: FontWeight.bold, fontSize: 18, color: AppColors.primary)),
                              Row(
                                children: [
                                  const Icon(Icons.flight_takeoff, size: 12, color: Colors.grey),
                                  const SizedBox(width: 4),
                                  Text('Ka imaanaya', style: GoogleFonts.poppins(color: Colors.grey[600], fontSize: 11)),
                                ],
                              ),
                            ],
                          ),
                          Column(
                            children: [
                              const Icon(Icons.flight, color: AppColors.secondary, size: 24),
                              Text(
                                '\$${flight['price']}',
                                style: GoogleFonts.poppins(fontWeight: FontWeight.bold, color: const Color(0xFF00C853), fontSize: 16),
                              ),
                            ],
                          ),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                              Text(flight['destination'], style: GoogleFonts.poppins(fontWeight: FontWeight.bold, fontSize: 18, color: AppColors.primary)),
                              Row(
                                children: [
                                  Text('Ku socda', style: GoogleFonts.poppins(color: Colors.grey[600], fontSize: 11)),
                                  const SizedBox(width: 4),
                                  const Icon(Icons.flight_land, size: 12, color: Colors.grey),
                                ],
                              ),
                            ],
                          ),
                        ],
                      ),
                      const SizedBox(height: 15),
                      Container(
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: Colors.grey[50],
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: Colors.grey.shade200),
                        ),
                        child: Column(
                          children: [
                            Row(
                              children: [
                                const Icon(Icons.person, size: 18, color: AppColors.primary),
                                const SizedBox(width: 8),
                                Text(
                                  'Rakaabka: ',
                                  style: GoogleFonts.poppins(color: Colors.grey[700]),
                                ),
                                Expanded(
                                  child: Text(
                                    booking['passengerName'],
                                    style: GoogleFonts.poppins(fontWeight: FontWeight.bold, fontSize: 15),
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 8),
                            Row(
                              children: [
                                const Icon(Icons.credit_card, size: 18, color: AppColors.primary),
                                const SizedBox(width: 8),
                                Text(
                                  'Passport: ',
                                  style: GoogleFonts.poppins(color: Colors.grey[700]),
                                ),
                                Expanded(
                                  child: Text(
                                    booking['passportNumber'],
                                    style: GoogleFonts.poppins(
                                      fontWeight: FontWeight.w800, // Bold
                                      fontSize: 15,
                                      color: Colors.black87,
                                      letterSpacing: 1.0,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                      
                      // Show Ticket Button if Approved
                      if (booking['status'] == 'Approved') ...[
                        const SizedBox(height: 15),
                        SizedBox(
                          width: double.infinity,
                          child: ElevatedButton.icon(
                            onPressed: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => TicketScreen(booking: booking),
                                ),
                              );
                            },
                            icon: const Icon(Icons.airplane_ticket, color: Colors.white),
                            label: const Text('Download Ticket', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: AppColors.primary,
                              padding: const EdgeInsets.symmetric(vertical: 12),
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                            ),
                          ),
                        ),
                      ],
                    ],
                  ],
                ),
              ),
            );
          },
        );
      },
    );

    if (widget.showAppBar) {
      return Scaffold(
        appBar: AppBar(
          title: Text('My Bookings', style: GoogleFonts.poppins(color: Colors.white)),
          backgroundColor: AppColors.primary,
          iconTheme: const IconThemeData(color: Colors.white),
        ),
        body: bodyContent,
      );
    } else {
      return bodyContent;
    }
  }

  Color _getStatusColor(String status) {
    switch (status) {
      case 'Approved': return Colors.green;
      case 'Rejected': return Colors.red;
      default: return Colors.orange;
    }
  }

  IconData _getStatusIcon(String status) {
    switch (status) {
      case 'Approved': return Icons.check_circle;
      case 'Rejected': return Icons.cancel;
      default: return Icons.hourglass_empty;
    }
  }
}
