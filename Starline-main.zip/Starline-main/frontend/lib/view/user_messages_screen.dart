import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:google_fonts/google_fonts.dart';
import '../viewmodels/message_viewmodel.dart';
import '../utils/constants.dart';

class UserMessagesScreen extends StatefulWidget {
  const UserMessagesScreen({super.key});

  @override
  State<UserMessagesScreen> createState() => _UserMessagesScreenState();
}

class _UserMessagesScreenState extends State<UserMessagesScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      Provider.of<MessageViewModel>(context, listen: false).fetchMyMessages();
    });
  }

  @override
  Widget build(BuildContext context) {
    final messageViewModel = Provider.of<MessageViewModel>(context);

    return Scaffold(
      appBar: AppBar(
        title: Text('Fariimahayga (Inbox)', style: GoogleFonts.poppins(color: Colors.white)),
        backgroundColor: AppColors.primary,
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: messageViewModel.isLoading
          ? const Center(child: CircularProgressIndicator())
          : messageViewModel.errorMessage != null
              ? Center(child: Text('Khalad: ${messageViewModel.errorMessage}'))
              : messageViewModel.messages.isEmpty
                  ? Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.mail_outline, size: 80, color: Colors.grey[400]),
                          const SizedBox(height: 20),
                          Text('Wali ma aadan dirin wax fariin ah.', style: GoogleFonts.poppins(color: Colors.grey)),
                        ],
                      ),
                    )
                  : ListView.builder(
                      itemCount: messageViewModel.messages.length,
                      padding: const EdgeInsets.all(16),
                      itemBuilder: (context, index) {
                        final message = messageViewModel.messages[index];
                        return Card(
                          margin: const EdgeInsets.only(bottom: 12),
                          elevation: 2,
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                          child: InkWell(
                            borderRadius: BorderRadius.circular(10),
                            child: Padding(
                              padding: const EdgeInsets.all(16.0),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: [
                                      Text(
                                        'Adiga (You)',
                                        style: GoogleFonts.poppins(fontWeight: FontWeight.bold, color: AppColors.primary),
                                      ),
                                      Text(
                                        message.createdAt.toString().substring(0, 16),
                                        style: TextStyle(fontSize: 12, color: Colors.grey[600]),
                                      ),
                                    ],
                                  ),
                                  const SizedBox(height: 8),
                                  Text(message.content, style: GoogleFonts.poppins()),
                                  const Divider(height: 20),
                                  if (message.reply != null) ...[
                                    Row(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        const Icon(Icons.support_agent, color: Colors.green, size: 20),
                                        const SizedBox(width: 10),
                                        Expanded(
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              Text(
                                                'Admin',
                                                style: GoogleFonts.poppins(fontWeight: FontWeight.bold, color: Colors.green[700]),
                                              ),
                                              const SizedBox(height: 4),
                                              Text(
                                                message.reply!,
                                                style: GoogleFonts.poppins(color: Colors.black87),
                                              ),
                                              if (message.repliedAt != null)
                                                Padding(
                                                  padding: const EdgeInsets.only(top: 4.0),
                                                  child: Text(
                                                    message.repliedAt.toString().substring(0, 16),
                                                    style: TextStyle(fontSize: 10, color: Colors.grey[500]),
                                                  ),
                                                ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ] else
                                    Row(
                                      children: [
                                        const Icon(Icons.hourglass_empty, size: 16, color: Colors.orange),
                                        const SizedBox(width: 5),
                                        Text(
                                          'Wali lagama soo jawaabin...',
                                          style: GoogleFonts.poppins(fontSize: 12, color: Colors.orange),
                                        ),
                                      ],
                                    ),
                                ],
                              ),
                            ),
                          ),
                        );
                      },
                    ),
    );
  }
}
