import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:google_fonts/google_fonts.dart';
import '../viewmodels/booking_viewmodel.dart';
import '../utils/constants.dart';

class AdminBookingsScreen extends StatefulWidget {
  const AdminBookingsScreen({super.key});

  @override
  State<AdminBookingsScreen> createState() => _AdminBookingsScreenState();
}

class _AdminBookingsScreenState extends State<AdminBookingsScreen> with SingleTickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
    WidgetsBinding.instance.addPostFrameCallback((_) {
      Provider.of<BookingViewModel>(context, listen: false).fetchBookings(isAdmin: true);
    });
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Maamulka Dalabaadka', style: GoogleFonts.poppins(color: Colors.white)),
        backgroundColor: AppColors.primary,
        iconTheme: const IconThemeData(color: Colors.white),
        bottom: TabBar(
          controller: _tabController,
          labelColor: Colors.white,
          unselectedLabelColor: Colors.white60,
          indicatorColor: AppColors.secondary,
          tabs: const [
            Tab(text: 'Pending'),
            Tab(text: 'Approved'),
            Tab(text: 'Rejected'),
          ],
        ),
      ),
      body: Consumer<BookingViewModel>(
        builder: (context, viewModel, child) {
          if (viewModel.isLoading) {
            return const Center(child: CircularProgressIndicator());
          }

          if (viewModel.errorMessage != null) {
            return Center(child: Text('Khalad: ${viewModel.errorMessage}'));
          }

          final pendingBookings = viewModel.bookings.where((b) => b['status'] == 'Pending').toList();
          final approvedBookings = viewModel.bookings.where((b) => b['status'] == 'Approved').toList();
          final rejectedBookings = viewModel.bookings.where((b) => b['status'] == 'Rejected').toList();

          return TabBarView(
            controller: _tabController,
            children: [
              _buildBookingList(pendingBookings, true),
              _buildBookingList(approvedBookings, false),
              _buildBookingList(rejectedBookings, false),
            ],
          );
        },
      ),
    );
  }

  Widget _buildBookingList(List<dynamic> bookings, bool isPending) {
    if (bookings.isEmpty) {
      return const Center(child: Text('Ma jiraan dalabaad noocaan ah.'));
    }

    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: bookings.length,
      itemBuilder: (context, index) {
        final booking = bookings[index];
        final flight = booking['flight'];
        final user = booking['user'];

        return Container(
          margin: const EdgeInsets.only(bottom: 20),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(20),
            boxShadow: [
              BoxShadow(
                color: Colors.grey.withOpacity(0.1),
                spreadRadius: 2,
                blurRadius: 10,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: Column(
            children: [
              // Header Section (Passenger & Status)
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.grey[50],
                  borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
                  border: Border(bottom: BorderSide(color: Colors.grey.shade200)),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Rakaabka',
                          style: GoogleFonts.poppins(color: Colors.grey[600], fontSize: 12),
                        ),
                        Text(
                          booking['passengerName'],
                          style: GoogleFonts.poppins(fontWeight: FontWeight.bold, fontSize: 16, color: AppColors.text),
                        ),
                      ],
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                      decoration: BoxDecoration(
                        color: _getStatusColor(booking['status']).withOpacity(0.1),
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: _getStatusColor(booking['status']).withOpacity(0.2)),
                      ),
                      child: Row(
                        children: [
                          Icon(_getStatusIcon(booking['status']), size: 14, color: _getStatusColor(booking['status'])),
                          const SizedBox(width: 6),
                          Text(
                            booking['status'],
                            style: GoogleFonts.poppins(
                              color: _getStatusColor(booking['status']),
                              fontWeight: FontWeight.bold,
                              fontSize: 12,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              
              Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: [
                    // Passport Info
                    Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: Colors.blue.withOpacity(0.1),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: const Icon(Icons.credit_card, size: 18, color: Colors.blue),
                        ),
                        const SizedBox(width: 12),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('Passport Number', style: GoogleFonts.poppins(color: Colors.grey[600], fontSize: 11)),
                            Text(
                              booking['passportNumber'], 
                              style: GoogleFonts.poppins(fontWeight: FontWeight.bold, fontSize: 14),
                            ),
                          ],
                        ),
                      ],
                    ),
                    const SizedBox(height: 15),
                    
                    // Flight Info
                    if (flight != null)
                      Container(
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: AppColors.primary.withOpacity(0.05),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: AppColors.primary.withOpacity(0.1)),
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(flight['departure'], style: GoogleFonts.poppins(fontWeight: FontWeight.bold, fontSize: 14)),
                                Text('Ka imaanaya', style: TextStyle(color: Colors.grey[600], fontSize: 10)),
                              ],
                            ),
                            const Icon(Icons.flight_takeoff, color: AppColors.primary, size: 18),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.end,
                              children: [
                                Text(flight['destination'], style: GoogleFonts.poppins(fontWeight: FontWeight.bold, fontSize: 14)),
                                Text('Ku socda', style: TextStyle(color: Colors.grey[600], fontSize: 10)),
                              ],
                            ),
                          ],
                        ),
                      )
                    else
                      const Text('Duulimaadka waa la tirtiray', style: TextStyle(color: Colors.red)),
                      
                    const SizedBox(height: 15),
                    // User Contact Info
                    if (user != null)
                      Row(
                        children: [
                          const Icon(Icons.alternate_email, size: 14, color: Colors.grey),
                          const SizedBox(width: 5),
                          Expanded(
                            child: Text(
                              'Dalbadaha: ${user['name']} (${user['email']})',
                              style: GoogleFonts.poppins(color: Colors.grey[600], fontSize: 11),
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                        ],
                      ),
                  ],
                ),
              ),

              // Action Buttons for Pending
              if (isPending) ...[
                const Divider(height: 1),
                Padding(
                  padding: const EdgeInsets.all(12),
                  child: Row(
                    children: [
                      Expanded(
                        child: OutlinedButton(
                          onPressed: () => _updateStatus(booking['_id'], 'Rejected'),
                          style: OutlinedButton.styleFrom(
                            foregroundColor: Colors.red,
                            side: const BorderSide(color: Colors.red),
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                            padding: const EdgeInsets.symmetric(vertical: 12),
                          ),
                          child: const Text('Diid (Reject)'),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: ElevatedButton(
                          onPressed: () => _updateStatus(booking['_id'], 'Approved'),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.green,
                            foregroundColor: Colors.white,
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                            padding: const EdgeInsets.symmetric(vertical: 12),
                            elevation: 0,
                          ),
                          child: const Text('Aqbal (Approve)'),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ],
          ),
        );
      },
    );
  }

  IconData _getStatusIcon(String status) {
    switch (status) {
      case 'Approved': return Icons.check_circle;
      case 'Rejected': return Icons.cancel;
      default: return Icons.hourglass_empty;
    }
  }

  Color _getStatusColor(String status) {
    switch (status) {
      case 'Approved': return Colors.green;
      case 'Rejected': return Colors.red;
      default: return Colors.orange;
    }
  }

  void _updateStatus(String id, String status) async {
    await Provider.of<BookingViewModel>(context, listen: false).updateStatus(id, status);
  }
}
