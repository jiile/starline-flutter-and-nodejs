import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../utils/constants.dart';

class TicketScreen extends StatelessWidget {
  final Map<String, dynamic> booking;

  const TicketScreen({super.key, required this.booking});

  @override
  Widget build(BuildContext context) {
    final flight = booking['flight'];
    final passengerName = booking['passengerName'];
    final passportNumber = booking['passportNumber'];

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: Text('Ticket-kaaga (Your Ticket)', style: GoogleFonts.poppins(color: Colors.white)),
        backgroundColor: AppColors.primary,
        iconTheme: const IconThemeData(color: Colors.white),
        actions: [
          IconButton(
            icon: const Icon(Icons.download),
            onPressed: () {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Ticket-ka waa la dajiyay (Downloaded)!')),
              );
            },
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            const SizedBox(height: 20),
            // Ticket Card
            Container(
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(20),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.1),
                    blurRadius: 20,
                    spreadRadius: 5,
                  ),
                ],
              ),
              child: Column(
                children: [
                   // Top Section (Airline Branding)
                  Container(
                    padding: const EdgeInsets.all(20),
                    decoration: const BoxDecoration(
                      color: AppColors.primary,
                      borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Row(
                          children: [
                            const Icon(Icons.flight_takeoff, color: Colors.white, size: 30),
                            const SizedBox(width: 10),
                            Text(
                              'Starline Travel',
                              style: GoogleFonts.poppins(
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                                fontSize: 20,
                              ),
                            ),
                          ],
                        ),
                        Text(
                          'BOARDING PASS',
                          style: GoogleFonts.poppins(
                            color: Colors.white70,
                            fontWeight: FontWeight.w600,
                            letterSpacing: 1.5,
                          ),
                        ),
                      ],
                    ),
                  ),
                  
                  // Middle Section (Flight Details)
                  Padding(
                    padding: const EdgeInsets.all(20),
                    child: Column(
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            _buildFlightInfo(flight['departure'], 'From'),
                            const Icon(Icons.airplane_ticket, color: AppColors.secondary, size: 30),
                            _buildFlightInfo(flight['destination'], 'To'),
                          ],
                        ),
                        const SizedBox(height: 30),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            _buildDetail('Passenger', passengerName),
                            _buildDetail('Date', flight['date'].toString().substring(0, 10)),
                          ],
                        ),
                        const SizedBox(height: 20),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            _buildDetail('Flight No', 'SL-${flight['_id'].toString().substring(0, 4)}'.toUpperCase()),
                            _buildDetail('Class', 'Economy'), // Hardcoded for now
                            _buildDetail('Seat', '12A'), // Random seat for now
                          ],
                        ),
                         const SizedBox(height: 20),
                         Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                             _buildDetail('Passport', passportNumber),
                             _buildDetail('Price', '\$${flight['price']}'),
                          ],
                         ),
                      ],
                    ),
                  ),

                  // Tear-off Line
                  Row(
                    children: List.generate(
                      20,
                      (index) => Expanded(
                        child: Container(
                          color: index % 2 == 0 ? Colors.transparent : Colors.grey.shade300,
                          height: 2,
                        ),
                      ),
                    ),
                  ),

                  // Barcode Section
                  Padding(
                    padding: const EdgeInsets.all(20),
                    child: Column(
                      children: [
                         // Approved Stamp
                         Container(
                           padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 5),
                           decoration: BoxDecoration(
                             border: Border.all(color: Colors.green, width: 2),
                             borderRadius: BorderRadius.circular(10),
                           ),
                           child: Text(
                             'APPROVED',
                             style: GoogleFonts.poppins(
                               color: Colors.green,
                               fontWeight: FontWeight.bold,
                               fontSize: 24,
                               letterSpacing: 2,
                             ),
                           ),
                         ),
                         const SizedBox(height: 20),
                        Container(
                          height: 60,
                          width: double.infinity,
                          color: Colors.black, // Placeholder for barcode
                          child: Center(
                            child: Text(
                              'I I I l I I l l I I I l l I I I',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 40,
                                fontFamily: 'Courier', // Monospace font simulates barcode appearance
                                fontWeight: FontWeight.w100,
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(height: 10),
                        Text(
                           booking['_id'].toString().toUpperCase(),
                           style: GoogleFonts.robotoMono(fontSize: 12, letterSpacing: 2), // Monospace font
                           // Attempting to use a standard font that looks like code if OCR not available
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 30),
            ElevatedButton.icon(
              onPressed: () {
                 ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Waa la daabacayaa (Printing)...')),
                );
              },
              icon: const Icon(Icons.print, color: Colors.white),
              label: const Text('Daabac (Print Ticket)', style: TextStyle(color: Colors.white)),
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.primary,
                padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 15),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFlightInfo(String code, String label) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label.toUpperCase(),
          style: GoogleFonts.poppins(color: Colors.grey, fontSize: 12),
        ),
        Text(
          code,
          style: GoogleFonts.poppins(
            fontWeight: FontWeight.bold,
            fontSize: 24,
            color: AppColors.text,
          ),
        ),
      ],
    );
  }

  Widget _buildDetail(String label, String value) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label.toUpperCase(),
          style: GoogleFonts.poppins(color: Colors.grey, fontSize: 10),
        ),
        const SizedBox(height: 2),
        Text(
          value,
          style: GoogleFonts.poppins(
            fontWeight: FontWeight.bold,
            fontSize: 14,
            color: Colors.black87,
          ),
        ),
      ],
    );
  }
}
