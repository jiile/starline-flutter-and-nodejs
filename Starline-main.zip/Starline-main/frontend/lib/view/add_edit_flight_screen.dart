import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:google_fonts/google_fonts.dart';
import '../models/flight.dart';
import '../viewmodels/flight_viewmodel.dart';
import '../utils/constants.dart';

class AddEditFlightScreen extends StatefulWidget {
  final Flight? flight;

  const AddEditFlightScreen({super.key, this.flight});

  @override
  State<AddEditFlightScreen> createState() => _AddEditFlightScreenState();
}

class _AddEditFlightScreenState extends State<AddEditFlightScreen> {
  final _formKey = GlobalKey<FormState>();
  late TextEditingController _airlineController;
  late TextEditingController _departureController;
  late TextEditingController _destinationController;
  late TextEditingController _priceController;
  late TextEditingController _descriptionController;
  DateTime _selectedDate = DateTime.now();

  @override
  void initState() {
    super.initState();
    _airlineController = TextEditingController(text: widget.flight?.airline ?? '');
    _departureController = TextEditingController(text: widget.flight?.departure ?? '');
    _destinationController = TextEditingController(text: widget.flight?.destination ?? '');
    _priceController = TextEditingController(text: widget.flight?.price.toString() ?? '');
    _descriptionController = TextEditingController(text: widget.flight?.description ?? '');
    if (widget.flight != null) {
      _selectedDate = widget.flight!.date;
    }
  }

  @override
  void dispose() {
    _airlineController.dispose();
    _departureController.dispose();
    _destinationController.dispose();
    _priceController.dispose();
    _descriptionController.dispose();
    super.dispose();
  }

  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: _selectedDate,
      firstDate: DateTime.now(),
      lastDate: DateTime(2030),
    );
    if (picked != null && picked != _selectedDate) {
      setState(() {
        _selectedDate = picked;
      });
    }
  }

  void _saveFlight() async {
    if (_formKey.currentState!.validate()) {
      final flightViewModel = Provider.of<FlightViewModel>(context, listen: false);
      
      final flight = Flight(
        id: widget.flight?.id ?? '', // ID is empty for new flights, backend handles generating it (but standard is to not send ID for create)
        // Note: For create, ID is ignored by backend usually, but our model requires it. 
        // We might need to adjust Model or ignore it. 
        // Actually, our Add logic in service sends body without ID, so purely local object needs dummy ID.
        airline: _airlineController.text,
        departure: _departureController.text,
        destination: _destinationController.text,
        price: double.parse(_priceController.text),
        date: _selectedDate,
        description: _descriptionController.text,
      );

      bool success;
      if (widget.flight == null) {
        success = await flightViewModel.addFlight(flight);
      } else {
        // Prepare updated flight with existing ID
        final updatedFlight = Flight(
            id: widget.flight!.id,
            airline: flight.airline,
            departure: flight.departure,
            destination: flight.destination,
            price: flight.price,
            date: flight.date,
            description: flight.description
        );
        success = await flightViewModel.updateFlight(updatedFlight);
      }

      if (success && mounted) {
        Navigator.pop(context);
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Guul! Xogta waa la keydiyay.')),
        );
      } else if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
           SnackBar(content: Text('Khalad: ${flightViewModel.errorMessage}')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final isEditing = widget.flight != null;

    return Scaffold(
      appBar: AppBar(
        title: Text(isEditing ? 'Wax ka badal Duulimaad' : 'Kudar Duulimaad'),
        backgroundColor: AppColors.primary,
        iconTheme: const IconThemeData(color: Colors.white),
        titleTextStyle: GoogleFonts.poppins(color: Colors.white, fontSize: 20),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              TextFormField(
                controller: _airlineController,
                decoration: const InputDecoration(labelText: 'Shirkadda Diyaaradaha (Airline)'),
                validator: (value) => value!.isEmpty ? 'Fadlan gali shirkadda' : null,
              ),
              const SizedBox(height: 10),
              Row(
                children: [
                  Expanded(
                    child: TextFormField(
                      controller: _departureController,
                      decoration: const InputDecoration(labelText: 'Ka imaanaya (Departure)'),
                      validator: (value) => value!.isEmpty ? 'Fadlan gali meesha laga imaanayo' : null,
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: TextFormField(
                      controller: _destinationController,
                      decoration: const InputDecoration(labelText: 'Ku socda (Destination)'),
                      validator: (value) => value!.isEmpty ? 'Fadlan gali meesha loo socdo' : null,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              TextFormField(
                controller: _priceController,
                decoration: const InputDecoration(labelText: 'Qiimaha (\$)'),
                keyboardType: TextInputType.number,
                validator: (value) => value!.isEmpty ? 'Fadlan gali qiimaha' : null,
              ),
              const SizedBox(height: 20),
              Row(
                children: [
                  Text('Taariikhda: ${_selectedDate.toLocal().toString().split(' ')[0]}'),
                  const Spacer(),
                  TextButton(
                    onPressed: () => _selectDate(context),
                    child: const Text('Dooro Taariikh'),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              TextFormField(
                controller: _descriptionController,
                decoration: const InputDecoration(labelText: 'Faahfaahin dheeraad ah (Optional)'),
                maxLines: 3,
              ),
              const SizedBox(height: 30),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: _saveFlight,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.primary,
                    padding: const EdgeInsets.symmetric(vertical: 15),
                  ),
                  child: Text(
                    isEditing ? 'Badal (Update)' : 'Keydi (Save)',
                    style: const TextStyle(color: Colors.white, fontSize: 16),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
