import 'package:flutter/material.dart';
import '../services/auth_service.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import '../utils/constants.dart';

class AuthViewModel extends ChangeNotifier {
  final AuthService _authService = AuthService();
  
  bool _isLoading = false;
  bool get isLoading => _isLoading;

  String? _errorMessage;
  String? get errorMessage => _errorMessage;

  bool _isAdmin = false;
  bool get isAdmin => _isAdmin;

  bool _isAuthenticated = false;
  bool get isAuthenticated => _isAuthenticated;

  // Helitaanka token-ka (Get Token)
  Future<String?> getToken() async {
    return await _authService.getToken();
  }

  // Hubinta haddii uu isticmaale soo galay (Check Auth status)
  Future<void> checkLoginStatus() async {
    final token = await _authService.getToken();
    final prefs = await SharedPreferences.getInstance();
    
    if (token != null) {
      _isAuthenticated = true;
      _isAdmin = prefs.getBool('isAdmin') ?? false;
    } else {
      _isAuthenticated = false;
      _isAdmin = false;
    }
    notifyListeners();
  }

  // Diiwaangelinta (Register)
  Future<bool> register(String name, String email, String password) async {
    _setLoading(true);
    try {
      await _authService.register(name, email, password);
      _errorMessage = null;
      return true;
    } catch (e) {
      _errorMessage = e.toString();
      return false;
    } finally {
      _setLoading(false);
    }
  }

  // Update Profile
  Future<bool> updateProfile(String name, String? password, String? oldPassword) async {
    _setLoading(true);
    try {
      final token = await _authService.getToken();
      if (token == null) return false;

      final response = await http.put(
        Uri.parse('${ApiConstants.registerEndpoint}/profile'),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $token',
        },
        body: jsonEncode({
          'name': name,
          if (password != null && password.isNotEmpty) 'password': password,
          if (oldPassword != null && oldPassword.isNotEmpty) 'oldPassword': oldPassword,
        }),
      );

      if (response.statusCode == 200) {
        return true;
      } else {
        final body = jsonDecode(response.body);
        _errorMessage = body['message'] ?? 'Khalad ayaa dhacay';
        return false;
      }
    } catch (e) {
      _errorMessage = e.toString();
      return false;
    } finally {
      _setLoading(false);
    }
  }

  // Soo galida (Login)
  Future<bool> login(String email, String password) async {
    _setLoading(true);
    try {
      final data = await _authService.login(email, password);
      if (data['token'] != null) {
        await _authService.saveToken(data['token']);

        // Save isAdmin status
        final prefs = await SharedPreferences.getInstance();
        _isAdmin = data['isAdmin'] ?? false;
        await prefs.setBool('isAdmin', _isAdmin);

        _isAuthenticated = true;
        _errorMessage = null;
        return true;
      }
      return false;
    } catch (e) {
      _errorMessage = e.toString();
      return false;
    } finally {
      _setLoading(false);
    }
  }

  // Ka bixida (Logout)
  Future<void> logout() async {
    await _authService.logout();
    _isAuthenticated = false;
    notifyListeners();
  }

  void _setLoading(bool value) {
    _isLoading = value;
    notifyListeners();
  }
}
