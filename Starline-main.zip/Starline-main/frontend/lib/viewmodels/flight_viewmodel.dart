import 'package:flutter/material.dart';
import '../models/flight.dart';
import '../services/flight_service.dart';

class FlightViewModel extends ChangeNotifier {
  final FlightService _flightService = FlightService();

  List<Flight> _flights = [];
  List<Flight> get flights => _flights;

  bool _isLoading = false;
  bool get isLoading => _isLoading;

  String? _errorMessage;
  String? get errorMessage => _errorMessage;

  // Soo qaadista duulimaadyada (Fetch flights)
  Future<void> fetchFlights() async {
    _setLoading(true);
    try {
      _flights = await _flightService.getFlights();
      _errorMessage = null;
    } catch (e) {
      _errorMessage = e.toString();
    } finally {
      _setLoading(false);
    }
  }

  // Ku darida duulimaad (Add Flight)
  Future<bool> addFlight(Flight flight) async {
    _setLoading(true);
    try {
      await _flightService.addFlight(flight);
      await fetchFlights(); // Refresh list
      return true;
    } catch (e) {
      _errorMessage = e.toString();
      return false;
    } finally {
      _setLoading(false);
    }
  }

  // Badalidda duulimaad (Update Flight)
  Future<bool> updateFlight(Flight flight) async {
    _setLoading(true);
    try {
      await _flightService.updateFlight(flight);
      await fetchFlights(); // Refresh list
      return true;
    } catch (e) {
      _errorMessage = e.toString();
      return false;
    } finally {
      _setLoading(false);
    }
  }

  // Tirtirida duulimaad (Delete Flight)
  Future<bool> deleteFlight(String id) async {
    _setLoading(true);
    try {
      await _flightService.deleteFlight(id);
      await fetchFlights(); // Refresh list
      return true;
    } catch (e) {
      _errorMessage = e.toString();
      return false;
    } finally {
      _setLoading(false);
    }
  }

  void _setLoading(bool value) {
    _isLoading = value;
    notifyListeners();
  }
}
