import 'package:flutter/material.dart';
import '../services/message_service.dart';
import '../models/message.dart';

class MessageViewModel extends ChangeNotifier {
  final MessageService _messageService = MessageService();

  List<Message> _messages = [];
  List<Message> get messages => _messages;

  bool _isLoading = false;
  bool get isLoading => _isLoading;

  String? _errorMessage;
  String? get errorMessage => _errorMessage;

  // Dir Fariin
  Future<bool> sendMessage(String email, String content) async {
    _setLoading(true);
    try {
      await _messageService.sendMessage(email, content);
      _errorMessage = null;
      return true;
    } catch (e) {
      _errorMessage = e.toString();
      return false;
    } finally {
      _setLoading(false);
    }
  }

  // Soo qaado fariimaha (Admin)
  Future<void> fetchMessages() async {
    _setLoading(true);
    try {
      _messages = await _messageService.getMessages();
      _errorMessage = null;
    } catch (e) {
      _errorMessage = e.toString();
    } finally {
      _setLoading(false);
    }
  }

  // Jawaab Fariinta (Admin)
  Future<bool> replyToMessage(String id, String reply) async {
    _setLoading(true);
    try {
      await _messageService.replyToMessage(id, reply);
      await fetchMessages(); // Refresh list
      return true;
    } catch (e) {
      _errorMessage = e.toString();
      return false;
    } finally {
      _setLoading(false);
    }
  }

  // Soo qaado fariimahayga (User)
  Future<void> fetchMyMessages() async {
    _setLoading(true);
    try {
      _messages = await _messageService.getMyMessages();
      _errorMessage = null;
    } catch (e) {
      _errorMessage = e.toString();
    } finally {
      _setLoading(false);
    }
  }

  void _setLoading(bool value) {
    _isLoading = value;
    notifyListeners();
  }
}
