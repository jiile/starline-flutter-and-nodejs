import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../utils/constants.dart';

class BookingViewModel extends ChangeNotifier {
  bool _isLoading = false;
  bool get isLoading => _isLoading;

  String? _errorMessage;
  String? get errorMessage => _errorMessage;

  List<dynamic> _bookings = [];
  List<dynamic> get bookings => _bookings;

  Future<String?> _getToken() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('token');
  }

  // Create Booking
  Future<bool> createBooking(String flightId, String passengerName, String passportNumber) async {
    _isLoading = true;
    notifyListeners();

    try {
      final token = await _getToken();
      final response = await http.post(
        Uri.parse('${ApiConstants.baseUrl}/bookings'),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $token',
        },
        body: jsonEncode({
          'flightId': flightId,
          'passengerName': passengerName,
          'passportNumber': passportNumber,
        }),
      );

      if (response.statusCode == 201) {
        return true;
      } else {
        _errorMessage = 'Failed to create booking';
        return false;
      }
    } catch (e) {
      _errorMessage = e.toString();
      return false;
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  // Get Bookings (Admin: All, User: My)
  Future<void> fetchBookings({bool isAdmin = false}) async {
    _isLoading = true;
    notifyListeners();

    try {
      final token = await _getToken();
      final endpoint = isAdmin ? '${ApiConstants.baseUrl}/bookings' : '${ApiConstants.baseUrl}/bookings/mybookings';
      
      final response = await http.get(
        Uri.parse(endpoint),
        headers: {
          'Authorization': 'Bearer $token',
        },
      );

      if (response.statusCode == 200) {
        _bookings = jsonDecode(response.body);
      } else {
        _errorMessage = 'Failed to load bookings';
      }
    } catch (e) {
      _errorMessage = e.toString();
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  // Update Status
  Future<bool> updateStatus(String bookingId, String status) async {
    try {
      final token = await _getToken();
      final response = await http.put(
        Uri.parse('${ApiConstants.baseUrl}/bookings/$bookingId/status'),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $token',
        },
        body: jsonEncode({'status': status}),
      );

      if (response.statusCode == 200) {
        await fetchBookings(isAdmin: true); // Refresh list
        return true;
      }
      return false;
    } catch (e) {
      _errorMessage = e.toString();
      return false;
    }
  }
}
